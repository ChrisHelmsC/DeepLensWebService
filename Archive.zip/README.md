DeepLens WebApp Service
