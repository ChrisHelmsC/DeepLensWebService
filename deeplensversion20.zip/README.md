DeepLens WebApp Service
